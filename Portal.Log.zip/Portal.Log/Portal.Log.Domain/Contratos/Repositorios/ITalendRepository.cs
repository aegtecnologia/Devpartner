﻿using Portal.Log.Domain.Entidades;

namespace Portal.Log.Domain.Contratos.Repositorios
{
    public interface ITalendRepository
    {
        void Save(TalendError log);
    }
}
