﻿using Portal.Log.Domain.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Domain.Contratos.Repositorios
{
    public interface IJobRepository
    {
        void Save(JobAction log);
        void Save(JobActionItem log);
    }
}
