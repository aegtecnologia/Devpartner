﻿using Portal.Log.Domain.Entidades;

namespace Portal.Log.Domain.Contratos.Repositorios
{
    public interface IActionRepository
    {
        void Save(ActionLog log);
    }
}
