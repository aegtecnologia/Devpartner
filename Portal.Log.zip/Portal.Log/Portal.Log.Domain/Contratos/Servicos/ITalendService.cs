﻿using Portal.Log.Domain.Entidades;

namespace Portal.Log.Domain.Contratos.Servicos
{
    public interface ITalendService
    {
        void CriarLog(TalendError log);
    }
}
