﻿using Portal.Log.Domain.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Domain.Contratos.Servicos
{
    public interface IBusinessService
    {
        void CriarLog(BusinessError log);
    }
}
