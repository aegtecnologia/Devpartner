﻿using Portal.Log.Domain.Entidades;

namespace Portal.Log.Domain.Contratos.Servicos
{
    public interface IActionService
    {
        void CriarLog(ActionLog log);
    }
}
