﻿using Portal.Log.Domain.Entidades;

namespace Portal.Log.Domain.Contratos.Servicos
{
    public interface IJobService
    {
        void CriarLog(JobAction log);
        void CriarLog(JobActionItem log);
    }
}
