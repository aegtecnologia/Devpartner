﻿using Portal.Log.Domain.Enumeradores;
using System;

namespace Portal.Log.Domain.Entidades
{
    public class BusinessError
    {
        public int BusinessErrorId { get; set; }
        public string CWId { get; set; }
        public string Token { get; set; }  
        public EnumModule Module { get; set; }
        public EnumSubmodule SubModule { get; set; }
        public EnumAction Action { get; set; }
        public string Description { get; set; }
        public string ResponseError { get; set; }
        public string TypeException { get; set; }
        public string InnerException { get; set; }
        public DateTime InsertDate { get; set; }
    }
}
