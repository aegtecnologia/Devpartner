﻿using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;

namespace Portal.Log.Domain.Entidades
{
    public class JobAction
    {
        public int JobActionId { get; set; }
        public EnumJobType Type { get; set; }
        public string Summary { get; set; }
        public virtual IEnumerable<JobActionItem> Results { get; set; }
        public DateTime InsertDate { get; set; }
    }
}
