﻿using Portal.Log.Domain.Enumeradores;
using System;

namespace Portal.Log.Domain.Entidades
{
    public class JobActionItem
    {
        public int JobActionItemId { get; set; }
        public int JobActionId { get; set; }
        public EnumJobType Type { get; set; }
        public string OldData { get; set; }
        public string NewData { get; set; }
        public EnumJobStatus Status { get; set; }
        public string Error { get; set; }
        public DateTime InsertDate { get; set; }
    }
}
