﻿using Portal.Log.Domain.Enumeradores;
using System;

namespace Portal.Log.Domain.Entidades
{
    public class ActionLog
    {
        public int ActionId { get; set; }
        public string CWId { get; set; }
        public string Token { get; set; }
        public EnumModule Module { get; set; }
        public EnumSubmodule SubModule { get; set; }
        public EnumAction ActionType { get; set; }
        public string Descricao { get; set; }
        public string Info { get; set; }
        public DateTime InsertDate { get; set; }
    }
}
