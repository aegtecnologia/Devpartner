﻿using Portal.Log.Domain.Enumeradores;
using System;

namespace Portal.Log.Domain.Entidades
{
    public class LogStructure
    {
        public int LogStructureId { get; set; }
        public string CWId { get; set; }
        public string Token { get; set; }
        public EnumModule Module { get; set; }
        public EnumSubmodule Submodule { get; set; }
        public EnumAction Action { get; set; }
        public DateTime InsertDate { get; set; }
    }
}
