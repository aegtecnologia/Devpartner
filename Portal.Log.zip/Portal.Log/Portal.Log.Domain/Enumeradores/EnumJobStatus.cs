﻿namespace Portal.Log.Domain.Enumeradores
{
    public enum EnumJobStatus
    {
        Success,
        Error
    }
}
