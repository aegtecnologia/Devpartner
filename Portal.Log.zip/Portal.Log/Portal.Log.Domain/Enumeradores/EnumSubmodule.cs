﻿namespace Portal.Log.Domain.Enumeradores
{
    public enum EnumSubmodule
    {
        Relatorio,
        CadastroDeTermo,
        AceiteCampanha,
        AssociacaoDeCupom
    }
}
