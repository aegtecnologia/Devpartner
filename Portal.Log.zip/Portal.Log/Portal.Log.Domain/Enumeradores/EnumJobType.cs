﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Domain.Enumeradores
{
    public enum EnumJobType
    {
        IBDP,
        SellIn,
        SellOut,
        Apuracao
    }
}
