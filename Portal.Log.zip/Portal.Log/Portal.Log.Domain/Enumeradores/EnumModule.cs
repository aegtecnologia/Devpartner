﻿namespace Portal.Log.Domain.Enumeradores
{
    public enum EnumModule
    {
        LOGIN, CAMPANHA, PLANOMETAS, IBDP
    }
}
