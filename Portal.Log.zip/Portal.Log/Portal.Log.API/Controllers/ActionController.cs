﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Portal.Log.API.Models;
using Portal.Log.API.Models.Request;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using System;
using System.Collections.Generic;

namespace Portal.Log.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActionController : ControllerBase
    {
        private IActionService _actionService;
        private IJobService _jobService;
        public ActionController(IActionService actionService, IJobService jobService)
        {
            _actionService = actionService;
            _jobService = jobService;
        }

        [Route("action")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<GenericResponse> Action([FromBody]ActionLogRequest logRequest)
        {
            var response = new GenericResponse();

            try
            {
                var log = new ActionLog()
                {
                    ActionType = logRequest.ActionType,
                    CWId = logRequest.CWId,
                    Descricao = logRequest.Descricao,
                    Info = logRequest.Info,
                    Module = logRequest.Module,
                    SubModule = logRequest.SubModule,
                    Token = logRequest.Token,
                    InsertDate = DateTime.Now
                };

                _actionService.CriarLog(log);

                if (log.ActionId == 0)
                    return BadRequest();

                response.LogId = log.ActionId;
                response.Sucesso = true;
            }
            catch (System.Exception erro)
            {
                response.LogId = 0;
                response.Sucesso = false;
                response.Mensagens.Add(erro.Message);
            }

            return response;
        }
        [Route("job")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<GenericResponse> Job([FromBody]JobActionRequest logRequest)
        {
            var response = new GenericResponse();

            try
            {
                var log = new JobAction()
                {
                    Type = logRequest.Type,
                    Summary = logRequest.Summary,
                    InsertDate = DateTime.Now
                };

                _jobService.CriarLog(log);

                if (log.JobActionId == 0)
                    return BadRequest();

                response.LogId = log.JobActionId;
                response.Sucesso = true;
            }
            catch (Exception erro)
            {
                response.LogId = 0;
                response.Sucesso = false;
                response.Mensagens.Add(erro.Message);
            }

            return response;
        }
        [Route("job/{logId}")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<GenericResponse> Job(int logId, [FromBody]JobActionItemRequest logRequest)
        {
            var response = new GenericResponse();

            try
            {
                var log = new JobActionItem()
                {
                    JobActionId = logId,
                    JobActionItemId = 0,
                    Error = logRequest.Error,
                    NewData = logRequest.NewData,
                    OldData = logRequest.OldData,
                    Status = logRequest.Status,
                    Type = logRequest.Type,
                    InsertDate = DateTime.Now
                };

                _jobService.CriarLog(log);

                if (log.JobActionId == 0)
                    return BadRequest();

                response.LogId = log.JobActionItemId;
                response.Sucesso = true;
            }   
            catch (Exception erro)
            {
                response.LogId = 0;
                response.Sucesso = false;
                response.Mensagens.Add(erro.Message);
            }

            return response;
        }
    }
}