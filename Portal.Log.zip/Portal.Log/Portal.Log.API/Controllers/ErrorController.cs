﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Portal.Log.API.Models;
using Portal.Log.API.Models.Request;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using System;

namespace Portal.Log.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ErrorController : ControllerBase
    {
        private ITalendService _talendService;
        private IBusinessService _businessService;
        public ErrorController(ITalendService talendService, IBusinessService businessService)
        {
            _talendService = talendService;
            _businessService = businessService;
        }

        [Route("talend")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<GenericResponse> Talend([FromBody] TalendRequest logRequest)
        {
            var response = new GenericResponse();

            try
            {
                var log = new TalendError()
                {
                    Action = logRequest.Action,
                    Body = logRequest.Body,
                    BodyResponse = logRequest.BodyResponse,
                    CWId = logRequest.CWId,
                    Description = logRequest.Description,
                    Headers = logRequest.Headers,
                    HttpStatusResponse = logRequest.HttpStatusResponse,
                    Module = logRequest.Module,
                    Submodule = logRequest.Submodule,
                    Token = logRequest.Token,
                    Url = logRequest.Url,
                    TalendErrorId = 0,
                    InsertDate = DateTime.Now
                };

                _talendService.CriarLog(log);

                if (log.TalendErrorId == 0)
                    return BadRequest();

                response.LogId = log.TalendErrorId;
                response.Sucesso = true;
            }
            catch (System.Exception erro)
            {
                response.LogId = 0;
                response.Sucesso = false;
                response.Mensagens.Add(erro.Message);
            }

            return response;
        }
        [Route("business")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<GenericResponse> Business([FromBody] BusinessRequest logRequest)
        {
            var response = new GenericResponse();

            try
            {
                var log = new BusinessError()
                {
                    Action = logRequest.Action,
                    BusinessErrorId = 0,
                    InnerException = logRequest.InnerException,
                    CWId = logRequest.CWId,
                    Description = logRequest.Description,
                    ResponseError = logRequest.ResponseError,
                    SubModule = logRequest.SubModule,
                    Module = logRequest.Module,
                    Token = logRequest.Token,
                    InsertDate = DateTime.Now,
                    TypeException = logRequest.TypeException,                    
                };

                _businessService.CriarLog(log);

                if (log.BusinessErrorId == 0)
                    return BadRequest();

                response.LogId = log.BusinessErrorId;
                response.Sucesso = true;
            }
            catch (Exception erro)
            {
                response.LogId = 0;
                response.Sucesso = false;
                response.Mensagens.Add(erro.Message);
            }

            return response;
        }
    }
}