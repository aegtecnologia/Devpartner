﻿using Portal.Log.Domain.Enumeradores;

namespace Portal.Log.API.Models.Request
{
    public class TalendRequest
    {
        public string CWId { get; set; }
        public string Token { get; set; }
        public EnumModule Module { get; set; }
        public EnumSubmodule Submodule { get; set; }
        public EnumAction Action { get; set; }
        public string Url { get; set; }
        public string Body { get; set; }
        public string Headers { get; set; }
        public int HttpStatusResponse { get; set; }
        public string BodyResponse { get; set; }
        public string Description { get; set; }
    }
}
