﻿using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.Log.API.Models.Request
{
    public class ActionLogRequest
    {
        public string CWId { get; set; }
        public string Token { get; set; }
        public EnumModule Module { get; set; }
        public EnumSubmodule SubModule { get; set; }
        public EnumAction ActionType { get; set; }
        public string Descricao { get; set; }
        public string Info { get; set; }
    }
}
