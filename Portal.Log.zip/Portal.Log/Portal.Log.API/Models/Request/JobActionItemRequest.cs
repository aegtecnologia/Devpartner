﻿using Portal.Log.Domain.Enumeradores;

namespace Portal.Log.API.Models.Request
{
    public class JobActionItemRequest
    {
        public EnumJobType Type { get; set; }
        public string OldData { get; set; }
        public string NewData { get; set; }
        public EnumJobStatus Status { get; set; }
        public string Error { get; set; }
    }
}
