﻿using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.Log.API.Models.Request
{
    public class JobActionRequest
    {
        public EnumJobType Type { get; set; }
        public string Summary { get; set; }
    }
}
