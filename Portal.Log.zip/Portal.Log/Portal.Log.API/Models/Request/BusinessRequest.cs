﻿using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.Log.API.Models.Request
{
    public class BusinessRequest
    {
        public string CWId { get; set; }
        public string Token { get; set; }
        public EnumModule Module { get; set; }
        public EnumSubmodule SubModule { get; set; }
        public EnumAction Action { get; set; }
        public string Description { get; set; }
        public string ResponseError { get; set; }
        public string TypeException { get; set; }
        public string InnerException { get; set; } 
    }
}
