﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.Log.API.Models
{
    public class GenericResponse
    {
        public bool Sucesso { get; set; }
        public int LogId { get; set; }
        public IList<string> Mensagens { get; set; }
        public GenericResponse()
        {
            Mensagens = new List<string>();
        }
    }
}
