﻿using FluentValidation;
using Portal.Log.Domain.Entidades;
using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Service.Validacoes
{
    public class TalendErrorValidator : AbstractValidator<TalendError>
    {
        public TalendErrorValidator()
        {
            Validar();
        }
        private void Validar()
        {
            RuleFor(c => c.Body)
                .NotEmpty();

            RuleFor(c => c.CWId)
                .NotEmpty();

            RuleFor(c => c.BodyResponse)
               .NotEmpty();

            RuleFor(c => c.Description)
              .NotEmpty();

            RuleFor(c => c.Headers)
              .NotEmpty();

            RuleFor(c => c.HttpStatusResponse)
              .NotEmpty();

            RuleFor(c => c.Url)
              .NotEmpty();

            RuleFor(c => c.Module)
               .Must(ValidaModulo)
               .WithMessage("Modulo inválido");

            RuleFor(c => c.Submodule)
               .Must(ValidaSubModulo)
               .WithMessage("Submodulo inválido");

            RuleFor(c => c.Token)
               .NotEmpty();
        }
        private bool ValidaModulo(EnumModule modulo)
        {
            return Enum.IsDefined(typeof(EnumModule), modulo);
        }
        private bool ValidaSubModulo(EnumSubmodule submodulo)
        {
            return Enum.IsDefined(typeof(EnumSubmodule), submodulo);
        }

    }
}