﻿using FluentValidation;
using Portal.Log.Domain.Entidades;
using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Service.Validacoes
{
    public class JobActionItemValidator : AbstractValidator<JobActionItem>
    {
        public JobActionItemValidator()
        {
            Validar();
        }
        private void Validar()
        {
            RuleFor(c => c.JobActionId)
                .NotEqual(0)
                .WithMessage("Código do  Job (pai) inválido");

            RuleFor(c => c.Type)
                .Must(ValidaTipo)
                .WithMessage("Tipo inválido");

            RuleFor(c => c.Status)
                .Must(ValidaStatus)
                .WithMessage("Situação inválida");

        }

        private bool ValidaTipo(EnumJobType tipo)
        {
            return Enum.IsDefined(typeof(EnumJobType), tipo);
        }
        private bool ValidaStatus(EnumJobStatus situacao)
        {
            return Enum.IsDefined(typeof(EnumJobStatus), situacao);
        }
    }
}