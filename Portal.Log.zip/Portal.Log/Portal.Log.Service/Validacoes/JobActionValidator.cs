﻿using FluentValidation;
using Portal.Log.Domain.Entidades;
using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Service.Validacoes
{
    public class JobActionValidator : AbstractValidator<JobAction>
    {
        public JobActionValidator()
        {
            Validar();
        }
        private void Validar()
        {
            RuleFor(c => c.Summary)
                .NotEmpty()
                .WithMessage("Sumario inválido");

            RuleFor(c => c.Type)
                .Must(ValidaTipo)
                .WithMessage("Tipo inválido");

        }

        private bool ValidaTipo(EnumJobType tipo)
        {
            return Enum.IsDefined(typeof(EnumJobType), tipo);
        }
    }
}