﻿using FluentValidation;
using Portal.Log.Domain.Entidades;
using Portal.Log.Domain.Enumeradores;
using System;

namespace Portal.Log.Service.Validacoes
{
    public class BusinessErrorValidator : AbstractValidator<BusinessError>
    {
        public BusinessErrorValidator()
        {
            Validar();
        }
        private void Validar()
        {
            RuleFor(c => c.Action)
                .Must(ValidaAcao);

            RuleFor(c => c.CWId)
                .NotEmpty();

            RuleFor(c => c.Description)
               .NotEmpty();

            RuleFor(c => c.InnerException)
               .NotEmpty();

            RuleFor(c => c.Module)
               .Must(ValidaModulo)
               .WithMessage("Modulo inválido");

            RuleFor(c => c.SubModule)
               .Must(ValidaSubModulo)
               .WithMessage("Submodulo inválido");

            RuleFor(c => c.ResponseError)
               .NotEmpty();

            RuleFor(c => c.Token)
               .NotEmpty();

            RuleFor(c => c.TypeException)
               .NotEmpty();
        }

        private bool ValidaModulo(EnumModule modulo)
        {
            return Enum.IsDefined(typeof(EnumModule), modulo);
        }
        private bool ValidaSubModulo(EnumSubmodule submodulo)
        {
            return Enum.IsDefined(typeof(EnumSubmodule), submodulo);
        }
        private bool ValidaAcao(EnumAction tipoAcao)
        {
            return Enum.IsDefined(typeof(EnumAction), tipoAcao);
        }
    }
}