﻿using FluentValidation;
using Portal.Log.Domain.Entidades;
using Portal.Log.Domain.Enumeradores;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Service.Validacoes
{
    public class ActionLogValidator : AbstractValidator<ActionLog>
    {
        public ActionLogValidator()
        {
            Validar();
        }
        private void Validar()
        {
            RuleFor(c => c.Info)
                .NotEmpty();

            RuleFor(c => c.CWId)
                .NotEmpty();

            RuleFor(c => c.Descricao)
               .NotEmpty();

            RuleFor(c => c.ActionType)
               .Must(ValidaTipoAcao)
               .WithMessage("Tipo de ação inválido");

            RuleFor(c => c.Module)
               .Must(ValidaModulo)
               .WithMessage("Modulo inválido");

            RuleFor(c => c.SubModule)
               .Must(ValidaSubModulo)
               .WithMessage("Submodulo inválido");

            RuleFor(c => c.Token)
               .NotEmpty();
        }

        private bool ValidaTipoAcao(EnumAction TipoAcao)
        {
            return Enum.IsDefined(typeof(EnumAction), TipoAcao);
        }
        private bool ValidaModulo(EnumModule modulo)
        {
            return Enum.IsDefined(typeof(EnumModule), modulo);
        }
        private bool ValidaSubModulo(EnumSubmodule submodulo)
        {
            return Enum.IsDefined(typeof(EnumSubmodule), submodulo);
        }
        
    }
}