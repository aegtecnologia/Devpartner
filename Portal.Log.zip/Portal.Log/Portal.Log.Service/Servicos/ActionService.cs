﻿using FluentValidation;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using Portal.Log.Service.Validacoes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Service.Servicos
{
    public class ActionService : IActionService
    {
        private IActionRepository _rep;
        public ActionService(IActionRepository rep)
        {
            _rep = rep;
        }
        public void CriarLog(ActionLog log)
        {
            var validador = new ActionLogValidator();
            validador.ValidateAndThrow(log);

            _rep.Save(log);
        }
    }
}
