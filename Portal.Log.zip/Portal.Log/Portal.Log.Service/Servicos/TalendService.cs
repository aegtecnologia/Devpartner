﻿using FluentValidation;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using Portal.Log.Service.Validacoes;

namespace Portal.Log.Service.Servicos
{
    public class TalendService : ITalendService
    {
        private ITalendRepository _rep;

        public TalendService (ITalendRepository rep)
        {
            _rep = rep;
        }
        public void CriarLog(TalendError log)
        {
            var validador = new TalendErrorValidator();
            validador.ValidateAndThrow(log);

            _rep.Save(log);
        }
    }
}
