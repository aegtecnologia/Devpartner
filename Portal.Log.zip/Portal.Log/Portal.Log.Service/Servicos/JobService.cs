﻿using FluentValidation;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using Portal.Log.Service.Validacoes;

namespace Portal.Log.Service.Servicos
{
    public class JobService : IJobService
    {
        private IJobRepository _rep;

        public JobService(IJobRepository rep)
        {
            _rep = rep;
        }
        public void CriarLog(JobAction log)
        {
            var validador = new JobActionValidator();
            validador.ValidateAndThrow(log);

            _rep.Save(log);
        }

        public void CriarLog(JobActionItem log)
        {
            var validador = new JobActionItemValidator();
            validador.ValidateAndThrow(log);

            _rep.Save(log);
        }
    }
}
