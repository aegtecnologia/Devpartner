﻿using FluentValidation;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Contratos.Servicos;
using Portal.Log.Domain.Entidades;
using Portal.Log.Service.Validacoes;
using System;

namespace Portal.Log.Service.Servicos
{
    public class BusinessService : IBusinessService
    {
        private IBusinessRepository _rep;

        public BusinessService(IBusinessRepository rep)
        {
            _rep = rep;
        }
        public void CriarLog(BusinessError log)
        {
            var validador = new BusinessErrorValidator();
            validador.ValidateAndThrow(log);

            _rep.Save(log);
        }
    }
}
