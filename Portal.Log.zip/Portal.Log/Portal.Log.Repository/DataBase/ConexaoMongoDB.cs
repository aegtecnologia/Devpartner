﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Portal.Log.Repository.Entidades;
using System;
using System.Security.Authentication;

namespace Portal.Log.Repository.DataBase
{
    public class ConexaoMongoDB
    {
        private IConfiguration configuration;
        //string connectionString = "mongodb://localhost:27017";
        //private string connectionString = @"mongodb://dev-temp-mongodb:Kcn078seHkKSKFhcVwISaiWfjpLXSduvUoggPzyvf7C5DqishmyivSQIPh5SAKe4SBrRRKqDiFHOMOHzPcUfqw==@dev-temp-mongodb.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
        //private string dataBaseName = "dbExemplo";
        private string connectionString = "";
        private string dataBaseName = "";

        private IMongoDatabase dataBase;

        public IMongoCollection<TbActionLog> ListaAction { get { return dataBase.GetCollection<TbActionLog>("actionlog"); } }
        public IMongoCollection<TbJobAction> ListaJobAction { get { return dataBase.GetCollection<TbJobAction>("jobaction"); } }
        public IMongoCollection<TbJobActionItem> ListaJobActionItem { get { return dataBase.GetCollection<TbJobActionItem>("jobactionitem"); } }
        public IMongoCollection<TbTalendError> ListaTalendError { get { return dataBase.GetCollection<TbTalendError>("talenderror"); } }
        public IMongoCollection<TbBusinessError> ListaBusinessError { get { return dataBase.GetCollection<TbBusinessError>("businesserror"); } }

        public ConexaoMongoDB(IConfiguration config)
        {
            configuration = config;
            connectionString = configuration["ConnectionString"];
            dataBaseName = configuration["DataBase"];

            MongoClientSettings settings = MongoClientSettings.FromUrl(new MongoUrl(connectionString));

            settings.SslSettings = new SslSettings()
            {
                EnabledSslProtocols = SslProtocols.Tls12
            };

            var clientDB = new MongoClient(settings);
            dataBase = clientDB.GetDatabase(dataBaseName);
        }
    }
}
