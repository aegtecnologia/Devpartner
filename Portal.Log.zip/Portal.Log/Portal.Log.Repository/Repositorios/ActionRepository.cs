﻿using Microsoft.Extensions.Configuration;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Entidades;
using Portal.Log.Repository.DataBase;
using Portal.Log.Repository.Entidades;
using System;

namespace Portal.Log.Repository.Repositorios
{
    public class ActionRepository : IActionRepository
    {
        private IConfiguration configuration;

        public ActionRepository(IConfiguration config)
        {
            configuration = config;
        }
        public void Save(ActionLog log)
        {
            var action = new TbActionLog()
            {
                ActionType = (int)log.ActionType,
                Module = (int)log.Module,
                SubModule = (int)log.SubModule,
                CWId = log.CWId,
                Descricao = log.Descricao,
                Info = log.Info,
                InsertDate = log.InsertDate,
                LogId = new Random().Next(999999),
                Token = log.Token
            };

            var conexao = new ConexaoMongoDB(configuration);

            var lista = conexao.ListaAction;
            lista.InsertOne(action);

            log.ActionId = action.LogId;
        }
    }
}
