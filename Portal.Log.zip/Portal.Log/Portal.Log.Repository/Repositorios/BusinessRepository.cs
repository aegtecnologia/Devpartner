﻿using Microsoft.Extensions.Configuration;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Entidades;
using Portal.Log.Repository.DataBase;
using Portal.Log.Repository.Entidades;
using System;

namespace Portal.Log.Repository.Repositorios
{
    public class BusinessRepository : IBusinessRepository
    {
        private IConfiguration configuration;
        public BusinessRepository(IConfiguration config)
        {
            configuration = config;
        }
        public void Save(BusinessError log)
        {
            var businessError = new TbBusinessError()
            {
                Action = (int)log.Action,
                Module = (int)log.Module,
                SubModule = (int)log.SubModule,
                CWId = log.CWId,
                InnerException = log.InnerException,
                ResponseError = log.ResponseError,
                Description = log.Description,
                TypeException = log.TypeException,
                InsertDate = log.InsertDate,
                LogId = new Random().Next(999999),
                Token = log.Token
            };

            var conexao = new ConexaoMongoDB(configuration);

            var lista = conexao.ListaBusinessError;
            lista.InsertOne(businessError);

            log.BusinessErrorId = businessError.LogId;
        }
    }
}
