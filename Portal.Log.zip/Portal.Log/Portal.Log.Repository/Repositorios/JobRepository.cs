﻿using Microsoft.Extensions.Configuration;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Entidades;
using Portal.Log.Repository.DataBase;
using Portal.Log.Repository.Entidades;
using System;

namespace Portal.Log.Repository.Repositorios
{
    public class JobRepository : IJobRepository
    {
        private IConfiguration configuration;
        public JobRepository(IConfiguration config)
        {
            configuration = config;
        }
        public void Save(JobAction log)
        {
            var job = new TbJobAction()
            {
                Summary = log.Summary,
                Type = (int)log.Type,
                InsertDate = log.InsertDate,
                LogId = new Random().Next(999999)
            };

            var conexao = new ConexaoMongoDB(configuration);

            var lista = conexao.ListaJobAction;
            lista.InsertOne(job);

            log.JobActionId = job.LogId;
        }

        public void Save(JobActionItem log)
        {
            var job = new TbJobActionItem()
            {
                JobActionId = log.JobActionId,
                Status = (int) log.Status,
                Error = log.Error,
                NewData = log.NewData,
                OldData = log.OldData,                
                Type = (int)log.Type,
                InsertDate = log.InsertDate,
                LogId = new Random().Next(999999)
            };

            var conexao = new ConexaoMongoDB(configuration);

            var lista = conexao.ListaJobActionItem;
            lista.InsertOne(job);

            log.JobActionItemId= job.LogId;
        }
    }
}
