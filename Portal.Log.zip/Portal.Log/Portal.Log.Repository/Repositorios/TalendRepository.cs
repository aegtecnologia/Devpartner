﻿using Microsoft.Extensions.Configuration;
using Portal.Log.Domain.Contratos.Repositorios;
using Portal.Log.Domain.Entidades;
using Portal.Log.Repository.DataBase;
using Portal.Log.Repository.Entidades;
using System;

namespace Portal.Log.Repository.Repositorios
{
    public class TalendRepository : ITalendRepository
    {
        private IConfiguration configuration;
        public TalendRepository(IConfiguration config)
        {
            configuration = config;
        }
        public void Save(TalendError log)
        {
            var talendError = new TbTalendError()
            {
                Action= (int)log.Action,
                Module = (int)log.Module,
                Submodule = (int)log.Submodule,
                CWId = log.CWId,
                Body = log.Body,
                BodyResponse = log.BodyResponse,
                Description = log.Description,
                Headers = log.Headers,
                HttpStatusResponse = log.HttpStatusResponse,
                Url = log.Url,
                InsertDate = log.InsertDate,
                LogId = new Random().Next(999999),
                Token = log.Token
            };

            var conexao = new ConexaoMongoDB(configuration);

            var lista = conexao.ListaTalendError;
            lista.InsertOne(talendError);

            log.TalendErrorId = talendError.LogId;
        }
    }
}
