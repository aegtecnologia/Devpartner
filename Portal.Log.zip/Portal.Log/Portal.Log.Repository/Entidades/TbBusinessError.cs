﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Repository.Entidades
{
    public class TbBusinessError
    {
        [BsonId()]
        public ObjectId Id { get; set; }
        [BsonRequired()]
        public int LogId { get; set; }
        [BsonRequired()]
        public string CWId { get; set; }
        [BsonRequired()]
        public string Token { get; set; }
        [BsonRequired()]
        public int Module { get; set; }
        [BsonRequired()]
        public int SubModule { get; set; }
        [BsonRequired()]
        public int Action { get; set; }
        [BsonRequired()]
        public string Description { get; set; }
        [BsonRequired()]
        public string ResponseError { get; set; }
        [BsonRequired()]
        public string TypeException { get; set; }
        [BsonRequired()]
        public string InnerException { get; set; }
        [BsonRequired()]
        public DateTime InsertDate { get; set; }
    }
}
