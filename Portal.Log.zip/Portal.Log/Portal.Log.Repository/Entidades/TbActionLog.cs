﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Portal.Log.Repository.Entidades
{
    public class TbActionLog
    {
        [BsonId()]
        public ObjectId Id { get; set; }
        [BsonRequired()]
        public int LogId { get; set; }
        [BsonRequired()]
        public string CWId { get; set; }
        [BsonRequired()]
        public string Token { get; set; }
        [BsonRequired()]
        public int Module { get; set; }
        [BsonRequired()]
        public int SubModule { get; set; }
        [BsonRequired()]
        public int ActionType { get; set; }
        [BsonRequired()]
        public string Descricao { get; set; }
        [BsonRequired()]
        public string Info { get; set; }
        [BsonRequired()]
        public DateTime InsertDate { get; set; }
    }
}
