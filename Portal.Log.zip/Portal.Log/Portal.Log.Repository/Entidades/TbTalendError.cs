﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Portal.Log.Repository.Entidades
{
    public class TbTalendError
    {
        [BsonId()]
        public ObjectId Id { get; set; }
        [BsonRequired()]
        public int LogId { get; set; }
        [BsonRequired()]
        public string CWId { get; set; }
        [BsonRequired()]
        public string Token { get; set; }
        [BsonRequired()]
        public int Module { get; set; }
        [BsonRequired()]
        public int Submodule { get; set; }
        [BsonRequired()]
        public int Action { get; set; }
        [BsonRequired()]
        public string Url { get; set; }
        [BsonRequired()]
        public string Body { get; set; }
        [BsonRequired()]
        public string Headers { get; set; }
        [BsonRequired()]
        public int HttpStatusResponse { get; set; }
        [BsonRequired()]
        public string BodyResponse { get; set; }
        [BsonRequired()]
        public string Description { get; set; }
        [BsonRequired()]
        public DateTime InsertDate { get; set; }
    }
}
