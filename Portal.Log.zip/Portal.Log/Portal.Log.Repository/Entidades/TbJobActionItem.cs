﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Repository.Entidades
{
    public class TbJobActionItem
    {
        [BsonId()]
        public ObjectId Id { get; set; }
        [BsonRequired()]
        public int LogId { get; set; }
        [BsonRequired()]
        public int JobActionId { get; set; }
        [BsonRequired()]
        public int Type { get; set; }
        [BsonRequired()]
        public string OldData { get; set; }
        [BsonRequired()]
        public string NewData { get; set; }
        [BsonRequired()]
        public int Status { get; set; }
        [BsonRequired()]
        public string Error { get; set; }
        [BsonRequired()]
        public DateTime InsertDate { get; set; }
    }
}
