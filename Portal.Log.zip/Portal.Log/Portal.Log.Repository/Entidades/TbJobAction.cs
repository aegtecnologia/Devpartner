﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Log.Repository.Entidades
{
    public class TbJobAction
    {
        [BsonId()]
        public ObjectId Id { get; set; }
        [BsonRequired()]
        public int LogId { get; set; }
        [BsonRequired()]
        public int Type { get; set; }
        [BsonRequired()]
        public string Summary { get; set; }
        [BsonRequired()]
        public DateTime InsertDate { get; set; }
    }
}
